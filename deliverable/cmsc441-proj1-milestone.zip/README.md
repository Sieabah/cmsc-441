Contributors:
Christopher Sidell (csidell1@umbc.edu)
Joshua Standiford (jstand1@umbc.edu)
